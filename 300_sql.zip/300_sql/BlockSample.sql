DECLARE
  lv_step VARCHAR2(1000);
  lv_nbr  NUMBER;
  
  CURSOR cur_po_order
  IS
      SELECT 1 AS CHK_FLAG
      FROM DUAl
      WHERE 1=2;
      
  rec_po_order cur_po_order%ROWTYPE;
  
  expt_common_api EXCEPTION;  -- ����API�G���[
BEGIN
  
  lv_step := 'STEP1';
  OPEN cur_po_order;
  FETCH cur_po_order INTO rec_po_order;
  CLOSE cur_po_order;
  
  DBMS_OUTPUT.put_line(lv_step);

  DBMS_OUTPUT.put_line(rec_po_order.CHK_FLAG || 'aaaaa');
  
  lv_nbr := 1/0;

  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('OTHERS-ERR: ' || DBMS_UTILITY.format_error_stack);
            
END;