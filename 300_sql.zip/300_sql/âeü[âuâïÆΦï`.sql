------�e�X�g�f�[�^�쐬�p
with tbl_param as (SELECT 'M_EIGYO_TANTOSHA' AS table_name,'FACTPJ003DEV_WEB_YO_AI' AS owner FROM DUAL)
SELECT
    cc.comments,
    c.column_name,
    c.data_type,
      case c.data_type
        WHEN 'VARCHAR2'   THEN TO_CHAR(c.char_length)
        WHEN 'NUMBER'     THEN TO_CHAR(c.data_precision)
        ELSE '0'
      END AS column_length,
     c.data_scale,
    c.NULLABLE
FROM
    all_tables t
    INNER JOIN all_tab_comments tc ON ( t.table_name = tc.table_name and t.owner = tc.owner )
    INNER JOIN all_tab_columns c ON ( t.table_name = c.table_name and t.owner = c.owner )
    INNER JOIN all_col_comments cc ON ( t.table_name = cc.table_name and t.owner = cc.owner and c.column_name = cc.column_name )
    INNER JOIN tbl_param tp ON ( t.table_name = tp.table_name and t.owner = tp.owner )
ORDER BY 
    c.column_id



--------DDL�쐬�p�ł����Adefault��long�^��String�ɕϊ��ł��Ȃ��B
with tbl_param as (SELECT 'M_EIGYO_TANTOSHA' AS table_name,'FACTPJ003DEV_WEB_YO_AI' AS owner FROM DUAL)
SELECT
    c.column_name
    ||' '||c.data_type
    ||'('||
      case c.data_type
        WHEN 'VARCHAR2'   THEN  c.char_length || ' CHAR'
        WHEN 'NUMBER'     THEN  c.data_precision || ',' || c.data_scale
        ELSE '0'
      END
    ||')' 
    --|| NVL2(c.DATA_DEFAULT,' ',' DEFAULT '||substr( c.DATA_DEFAULT, 1, 1000 )||' ')
    || CASE c.NULLABLE WHEN 'Y' THEN 'NOT NULL' END 
    AS DDL
    ,c.column_id,
    t.table_name,
    tc.comments,
    c.column_name,
    '' AS comments,
        CASE c.data_type
            WHEN 'NUMBER'   THEN '2'
            WHEN 'DATE'     THEN '4'
            ELSE '0'
        END
    AS data_type,
    nvl(
        c.data_precision,
        c.data_length
    ) AS data_length,
    c.data_scale AS decimalpos,
    'N' AS subrecord
    ,c.*
FROM
    all_tables t
    INNER JOIN all_tab_comments tc ON ( t.table_name = tc.table_name and t.owner = tc.owner )
    INNER JOIN all_tab_columns c ON ( t.table_name = c.table_name and t.owner = c.owner )
    INNER JOIN tbl_param tp ON ( t.table_name = tp.table_name and t.owner = tp.owner )
ORDER BY 
    c.column_id







-----------------------------------------------------------

with tbl_param as (SELECT 'M_EIGYO_TANTOSHA' AS table_name,'FACTPJ003DEV_WEB_YO_AI' AS owner FROM DUAL)
SELECT
    c.column_id,
    t.table_name,
    tc.comments,
    c.column_name,
    '' AS comments,
        CASE c.data_type
            WHEN 'NUMBER'   THEN '2'
            WHEN 'DATE'     THEN '4'
            ELSE '0'
        END
    AS data_type,
    nvl(
        c.data_precision,
        c.data_length
    ) AS data_length,
    c.data_scale AS decimalpos,
    'N' AS subrecord
FROM
    all_tables t
    INNER JOIN all_tab_comments tc ON ( t.table_name = tc.table_name and t.owner = tc.owner )
    INNER JOIN all_tab_columns c ON ( t.table_name = c.table_name and t.owner = c.owner )
    INNER JOIN tbl_param tp ON ( t.table_name = tp.table_name and t.owner = tp.owner )
ORDER BY 
    c.column_id
    





-----------------------------------------------------------

select 
 tc.* 
from 
    all_tables t
    ,all_tab_columns tc
WHERE
    t.table_name = tc.table_name
    AND t.owner = tc.owner
    AND t.table_name = 'M_EIGYO_TANTOSHA'
    AND t.owner = 'FACTPJ003DEV_WEB_YO_AI'



SELECT
    t.*
FROM
    all_tab_comments t
WHERE
        t.table_name = 'M_EIGYO_TANTOSHA'
    AND
        t.owner = 'FACTPJ003DEV_WEB_YO_AI'